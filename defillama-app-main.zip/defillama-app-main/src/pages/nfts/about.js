import About from '../about'

function AboutPage() {
	return <About />
}

export default AboutPage
