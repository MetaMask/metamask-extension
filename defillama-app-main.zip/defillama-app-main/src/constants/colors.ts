export const primaryColor = '#2172E5'
