# @metamask/mfa-wallet-network

Network transport using Centrifuge and Noise KK encryption for the MetaMask MFA Wallet SDK.

This package implements `NetworkManager` / `RootNetworkSession` with:

- Centrifugo WebSocket transport
- Dedicated directional channels per peer pair
- Noise Protocol KK handshake via `@metamask/mfa-wallet-e2ee`
- Encrypted message envelopes (session ID, message type, and payload)

## Installation

```bash
yarn add @metamask/mfa-wallet-network
```

or

```bash
npm install @metamask/mfa-wallet-network
```

## Usage

```typescript
import { CentrifugeNetworkManager } from '@metamask/mfa-wallet-network';

const networkManager = new CentrifugeNetworkManager({
  url: 'wss://your-centrifugo-server.com/connection/websocket',
  randomBytes: crypto,
  onError: (error) => {
    // Abort the current protocol operation and report the transport failure.
    console.error('Network transport failed:', error);
  },
  reconnect: {
    minDelay: 250,
    maxDelay: 5_000,
  },
  queueLimits: {
    message: {
      maxMessages: 256,
      maxBytes: 8 * 1024 * 1024,
      maxWaiters: 128,
    },
  },
});

const identity = await networkManager.createIdentity();
const session = await networkManager.createSession(identity, 'session-123');

session.sendMessage(
  peerPartyId,
  'greeting',
  new TextEncoder().encode('Hello!'),
);
const response = await session.receiveMessage(peerPartyId, 'response');

await session.disconnect();
await networkManager.disconnect();
```

Asynchronous transport failures—including send, inbound processing, history
recovery, queue overflow, and connection loss—are reported through `onError`.
Because `NetworkSession.sendMessage` is fire-and-forget, applications should use
this callback to abort affected protocol operations. If no handler is
configured, failures are logged to `console.error`. Exceptions thrown by the
handler are contained and logged rather than escaping from transport callbacks.

## Failure and resource limits

Protocol and Noise handshake queues are bounded by message count, total payload
bytes, and pending receiver count. The defaults are 256 messages / 8 MiB / 128
waiters for protocol messages and 8 messages / 64 KiB / 8 waiters for handshake
traffic. A limit violation raises `QueueOverflowError`, closes the affected peer
channel, rejects pending receives, and reports the failure through `onError`.

Centrifuge automatically reconnects the shared client using the configured
`reconnect` delays. A connection loss is terminal for sessions that were already
active: their channels and pending receives are failed with
`TransportDisconnectedError`. The reconnected client may be used to create new
sessions. This package does not transparently resume an interrupted MPC session.

Publications are attempted once. Publish failures are reported through
`onError`; this package does not retry them.

## Delivery semantics

The transport routes each message by sender, session ID, and message type. It
does not guarantee ordering across message types or exactly-once delivery;
Centrifugo history recovery can redeliver a publication, and live and recovered
publications can arrive in a different order.

Protocols using this package must:

- Use each message type for at most one logical message from a sender within a
  session or subsession.
- Tolerate duplicate delivery, for example by making message handling
  idempotent.
- Avoid depending on delivery order between different message types.

These constraints allow a receiver to request messages by type independently
of their network arrival order. A protocol that requires ordered or
exactly-once delivery must add its own authenticated sequence numbers or
message identifiers and deduplicate above this transport.

## Broker access risk

Noise KK authenticates peers and protects message contents, but it does not
control access to Centrifugo. The repository's Centrifugo configuration permits
anonymous publish, subscribe, and history access for the `mfa` namespace.
Production deployments using anonymous broker access must provide rate limiting
and denial-of-service protection in the surrounding infrastructure.

Anonymous clients cannot decrypt messages or forge authenticated plaintext
without a party's private key. They can still observe traffic metadata, publish
invalid frames, or replay captured publications. These actions may disrupt a
session or consume resources even when they remain within rate limits.
Deployments that do not accept this residual risk should additionally enforce
authenticated, channel-scoped publish and subscribe authorization.

## License

MIT
