# @metamask/tss-dkls23-lib

A WebAssembly-based library for ecdsa-secp256k1-compliant threshold signing using the DKLS23 protocol.

Source code: https://github.com/MetaMask/dkls23

## Prerequisites

To build from Rust source, you need:

- [Rust](https://rustup.rs/) toolchain
- [wasm-pack](https://rustwasm.github.io/wasm-pack/installer/)

Install wasm-pack:

```bash
cargo install wasm-pack
# or
curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh
```

## Building

### Full build (WASM + TypeScript)

```bash
yarn build
```

This will:
1. Build the Rust wasm wrapper crate in `rust/dkls23-wasm`
2. Generate the WASM package using wasm-pack (output to `src/pkg/`)
3. Build the TypeScript bundle (output to `dist/`)

### TypeScript only (using existing WASM)

```bash
yarn build:ts
```

### WASM only

```bash
yarn build:wasm
```

The DKLS23 Rust source is vendored as a git submodule at `rust/dkls23`.
