# `@metamask/mfa-wallet-test-util`

Test utilities for the MetaMask MFA SDK.

## Installation

`yarn add @metamask/mfa-wallet-test-util`

or

`npm install @metamask/mfa-wallet-test-util`

## Contributing

This package is part of a monorepo. Instructions for contributing can be found in the [monorepo README](https://github.com/MetaMask/mfa-wallet-sdk#readme).
