# Development

Several files which are needed for developing on MetaMask.

Usually each file or directory contains information about its scope / usage.
