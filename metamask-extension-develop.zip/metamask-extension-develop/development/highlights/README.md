### highlights

the purpose of this directory is to house utilities for generating "highlight" messages for the metamaskbot comment based on changes included in the PR