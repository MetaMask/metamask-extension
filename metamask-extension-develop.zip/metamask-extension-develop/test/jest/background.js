import * as actions from '../../ui/store/actions';

export const setBackgroundConnection = (backgroundConnection = {}) => {
  actions._setBackgroundConnection(backgroundConnection);
};
