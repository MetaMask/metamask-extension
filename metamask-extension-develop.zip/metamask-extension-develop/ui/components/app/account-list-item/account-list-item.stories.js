import React from 'react';
import AccountListItem from './account-list-item';

export default {
  title: 'AccountListItem',
  id: __filename,
};

export const AccountListItemComponent = () => {
  return <AccountListItem />;
};
