export const CAVEAT_NAMES = {
  exposedAccounts: 'exposedAccounts',
  primaryAccountOnly: 'primaryAccountOnly',
};
