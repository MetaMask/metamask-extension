module.exports = {
  fetch: () => 0
}