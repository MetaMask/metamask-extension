const UiPoolDataProvider = require("./UiPoolDataProvider.json");

module.exports = {
  UiPoolDataProvider,
};
