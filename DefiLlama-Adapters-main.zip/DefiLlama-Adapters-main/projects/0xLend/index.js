const { usdCompoundExports } = require("../helper/compound");
module.exports = {
    kcc: usdCompoundExports("0x337d8719f70D514367aBe780F7c1eAd1c0113Bc7", "kcc", "0x309f1639018e8B272126C4B99af442AA25Dcd1F2")
}