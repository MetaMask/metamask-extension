Hello,

To get listed on DefiLlama, simply create a PR with a script that follows this guide: https://docs.llama.fi/list-your-project/submit-a-project. All chains and protocols welcome.

When creating a PR, there will be a few questions to help us list you as soon as possible.

Many thanks,
Alex


https://github.com/DefiLlama/defillama-adapters
