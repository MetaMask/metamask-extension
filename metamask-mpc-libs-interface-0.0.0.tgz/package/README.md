# @metamask/mpc-libs-interface

A TypeScript interface for the MPC libraries.

## Building

```bash
yarn build
```
