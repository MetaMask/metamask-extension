# @metamask/tss-dkls19-lib

A WebAssembly-based library for ecdsa-secp256k1-compliant threshold signing using the DKLS19 protocol.

Source code: https://github.com/MetaMask/dkls

## Prerequisites

To build from Rust source, you need:

- [Rust](https://rustup.rs/) toolchain
- [wasm-pack](https://rustwasm.github.io/wasm-pack/installer/)

Install wasm-pack:

```bash
cargo install wasm-pack
# or
curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh
```

## Building

### Full build (WASM + TypeScript)

```bash
yarn build
```

This will:
1. Clone/update the Rust source from GitHub (into `rust-src/`)
2. Build the WASM package using wasm-pack (output to `src/pkg/`)
3. Build the TypeScript bundle (output to `dist/`)

### TypeScript only (using existing WASM)

```bash
yarn build:ts
```

### WASM only

```bash
yarn build:wasm
```

### Environment Variables

- `RUST_REF` - Git ref to checkout: branch name, tag, or commit hash

```bash
# Use a specific tag
RUST_REF=v1.0.0 yarn build:wasm

# Use a specific commit
RUST_REF=abc123def yarn build:wasm

# Use a branch
RUST_REF=main yarn build:wasm
```
